﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Abstracts
{
    //1. abstract class ların nesnesi oluşturulamaz
    public  abstract class Calisan
    {

        //tüm çalışanlara bir soru sorcam
        //bu class tan türeyen tüm classlar maasinizNedir metodunu implemente etmek(uygulamak) zorundadırlar
        public  abstract double maasiniziNedir();

        public void mesaiyeBasla(string isim)
        {
            Console.WriteLine(isim + " mesaiye başladı");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Abstracts
{
    public class Mudur : Calisan
    {
        public override double maasiniziNedir()
        {
            return 60000.0;
        }
    }
}

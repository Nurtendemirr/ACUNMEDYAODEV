﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Abstracts
{
    public class Programci : Calisan
    {
        public override double maasiniziNedir()
        {
            return 40000.0;
        }
    }
}

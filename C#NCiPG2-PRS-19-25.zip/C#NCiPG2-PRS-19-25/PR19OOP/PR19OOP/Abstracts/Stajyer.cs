﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Abstracts
{
    public class Stajyer : Calisan
    {
        public override double maasiniziNedir()
        {
            return 5000.0;
        }
    }
}

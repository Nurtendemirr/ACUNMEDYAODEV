﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PR19OOP.Interfaces;

namespace PR19OOP.Classes
{
    //Anne class ı Insan class ından türemiştir
    //Insan class ındaki tüm public olan değişkenlere ve metodlara Anne class ından erişebilir
    //Anne classı aynı zamanda IOzellik interface inden de türemiştir. 
    public class Anne : Insan,IOzellik,IOzellik2
    {
        public void dinle(string isim)
        {
            Console.WriteLine(isim + " dinliyor...");
        }

        public void oku(string isim)
        {
            Console.WriteLine(isim + " okuyor...");
        }

        public void yaz(string isim)
        {
            Console.WriteLine(isim + " yazıyor...");
        }
    }
}

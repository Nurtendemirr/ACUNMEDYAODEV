﻿using PR19OOP.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Classes
{
    //Baba class ı hem insan class ından türemiştir aynı zaman Iozellik interface inden de türemiştir. 
    public class Baba : Insan,IOzellik
    {
        public void oku(string isim)
        {
            Console.WriteLine(isim + " okuyor...");
        }

       
    }
}

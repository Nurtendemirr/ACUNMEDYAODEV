﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Classes
{
    public class Cocuk : Insan
    {

        public string sifat;


        public void adSoyadSifatYaz(string isim,string soyisim,string sifati)
        {
            Console.WriteLine(isim + " " + soyisim + " " + sifati);

            
        }

    }
}

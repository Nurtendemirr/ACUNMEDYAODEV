﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Classes
{
    public class Insan : Object
    { //başlangıç scope

        //properties değişkenler 
        //access modifiers (public,private,proctected) dataType degişkenAdi
        //alfanümerik içinde hem harf hem rakam olabilir 
        public string adi;
        public string soyadi;
        //tam sayısal verileri saklamamızı sağlar
        public int yas;
        //küsuratlı sayıları saklamamızı sağlar
        public double maas;
        //true yada false şeklinde veri saklamamızı sağlar. 
        public bool cinsiyet;

        //metotlar 2 ye ayrılılar
        //geriye değer döndüren ve geriye döndürmeyen
        //access modifiers dönüştipi metodAdi()  {     }
        //geriye değer döndürmeyen parametre almayan adı uyu olan bir metod tanımlayacağız.
        public void uyu(string isim,string soyisim)
        {
            Console.WriteLine(isim +" "+soyisim+" uyuyor...");
        }

        public void ekranaYaz(string isim, string soyisim)
        {
            Console.WriteLine("Kişinin adı : " + isim + " kişinin soyadı : " + soyisim);
        }

        public int yasHesapla(int dogumYili)
        {
            int sonuc = 0;
            //bulunduğumuz yılı veriyor 
            sonuc =  DateTime.Now.Year- dogumYili;
            return sonuc;
        }

        //boş constructor
        //Class ın ismi ile aynı geri dönüş tipi olmayan bir metod devreye girer
        public Insan()
        {
           // adi = "metin";
        }

        //parametre alan constructor 

        public Insan(string isim, string soyisim)
        {
            adi = isim;
            soyadi = soyisim;
        }

        //parametre alan constructor
        public Insan(string adi,string soyadi,int yas,double maas, bool cinsiyet)
        {
            this.adi = adi;
            this.soyadi = soyadi;
            this.yas = yas;
            this.maas = maas;
            this.cinsiyet = cinsiyet;
        }
    } //bitiş scope 
}

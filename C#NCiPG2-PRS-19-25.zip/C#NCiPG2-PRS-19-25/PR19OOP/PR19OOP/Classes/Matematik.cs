﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Classes
{
    public class Matematik
    {

        //2 tane int tipinde parametre alan ve geriye int tipinde değer dönen adı topla olan bir metod
        //overload
        public int topla(int sayi1,int sayi2)
        {
            int sonuc = 0;
            sonuc = sayi1 + sayi2;
            return sonuc;
        }

        public int topla(int sayi1, int sayi2,int sayi3)
        {
            int sonuc = 0;
            sonuc = sayi1 + sayi2+ sayi3;
            return sonuc;
        }

        public int topla(int sayi1, int sayi2, int sayi3,int sayi4)
        {
            int sonuc = 0;
            sonuc = sayi1 + sayi2 + sayi3+sayi4;
            return sonuc;
        }

        public int topla(int[] sayilar)
        {

            int sayiToplam = 0;
            for (int x = 0; x < sayilar.Length; x++)
            {
                Console.WriteLine("Sayı  : " + sayilar[x]);
                // sayiToplam = sayiToplam + sayilar[x];
                sayiToplam += sayilar[x];
            }
            return sayiToplam;
        }

        public int cikar(int sayi1,int sayi2)
        {
            int  sonuc = 0;
            sonuc = sayi1 - sayi2;
            return sonuc;
        }

        public int carp(int sayi1, int sayi2)
        {
            return sayi1 * sayi2;
        }

        public int carp(int sayi1, int sayi2,int sayi3)
        {
            return sayi1 * sayi2* sayi3;
        }

        public int carp(int[] sayilar)
        {
            return 0;
        }

        public int bol(int sayi1, int sayi2)
        {
            return sayi1 / sayi2;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Constructors
{
    public class Goz
    {

        public string renk;

        //parametre alan constructor 
        public Goz(string renk)
        {
            this.renk = renk;
        }   
    }
}

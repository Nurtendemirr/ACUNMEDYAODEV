﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Constructors
{
    public class Kafa
    {
        //Composition 
        public Goz goz;
        public Kulak kulak;
        public Burun burun;


        //kötü senaryo
        public string gozRengi;
        public string retina;
        public int gozYukseklik;
        public int gozGenislik;
        public string kulakSekil;
        public int kulakGenislik;
        public int kulakYukseklik;
        public string burunTip;
        public int burunGenislik;
        public int burunYukseklik;

        //parametre alan constructor 
        public Kafa(Goz goz, Kulak kulak,Burun burun)
        {
            this.goz = goz;
            this.kulak = kulak;
            this.burun = burun;
        }

        //
        //public Kafa(string gozRengi, string )


    }
}

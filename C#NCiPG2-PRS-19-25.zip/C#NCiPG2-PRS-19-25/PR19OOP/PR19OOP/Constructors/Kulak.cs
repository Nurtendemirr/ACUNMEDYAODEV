﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Constructors
{
    public class Kulak
    {
        public string sekil;


        //parametre alan constructor 
        public Kulak(string sekil)
        {
            this.sekil = sekil;
        }
    }
}

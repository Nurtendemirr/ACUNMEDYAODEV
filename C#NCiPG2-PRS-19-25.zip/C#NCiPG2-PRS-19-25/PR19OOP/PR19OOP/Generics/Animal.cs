﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace PR19OOP.Generics
{
    public class Animal
    {
        public string nickName;

        public override string ToString()
        {
            return "Animal [nickName=" + nickName + "]";
        }

        public void save(Animal animal)
        {
            Console.WriteLine(animal.ToString() + " database kaydedildi");
        }
    }
}

﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Generics
{
    public class ArrayListIbrahim : ArrayList
    {

        public void listele()
        {
            Console.WriteLine("listendi");
        }
    }
}

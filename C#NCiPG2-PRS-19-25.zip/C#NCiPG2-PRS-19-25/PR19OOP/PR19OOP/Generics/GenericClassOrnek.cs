﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Generics
{
    public class GenericClassOrnek<T>
    {
        public void Save(T obj)
        {
            Console.WriteLine(obj.ToString() + " database kaydedildi.");
        }
    }
}

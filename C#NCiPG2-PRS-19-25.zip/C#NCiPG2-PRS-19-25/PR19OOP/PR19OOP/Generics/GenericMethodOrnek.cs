﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Generics
{
    public class GenericMethodOrnek
    {
        //T Type anlamına gelir person, animal,
        //Entity Framework generic method
        public void save<T>(T obj)
        {
            Console.WriteLine(obj.ToString() + " database kaydedildi");
            //ADO.NET ENTITY contex.saveDatabaseChanges();
        }

        //genericMethod
        public void Yazdir<T>(List<T> list)
        {
            // foreach (var item in list)
            foreach (T obj in list)
            {
                Console.WriteLine(obj);
            }
        }

    }
}

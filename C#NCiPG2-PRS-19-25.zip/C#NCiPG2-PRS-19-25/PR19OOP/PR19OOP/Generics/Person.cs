﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Generics
{
    public class Person 
    {
        public string name;

        public override string ToString()
        {
            return "Personel [name=" + name + "]";
        }

        public void save(Person p)
        {
            Console.WriteLine(p.ToString() + " database kaydedildi");
        }
    }
}

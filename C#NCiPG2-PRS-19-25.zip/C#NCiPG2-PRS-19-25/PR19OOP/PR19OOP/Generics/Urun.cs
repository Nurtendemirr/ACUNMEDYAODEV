﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace PR19OOP.Generics
{
    public class Urun
    {

        public string urunAdi;
        public string marka;

        public override string ToString()
        {
            return "Urun [urunAdi=" + urunAdi + " marka="+marka+"]";
        }


       // public Urun(string urunAdi)
       // {
          //  this.urunAdi = urunAdi;
       // }   
    }
}

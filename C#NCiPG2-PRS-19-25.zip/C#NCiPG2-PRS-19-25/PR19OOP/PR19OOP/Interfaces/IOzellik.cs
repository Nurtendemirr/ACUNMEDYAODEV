﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Interfaces
{

    //1. multiple inheritance - coklu kalıtıma destek verir
    //2. sözleşmeye benzetilebilir. 
    public interface IOzellik
    {
       public void oku(string isim);
    }
}

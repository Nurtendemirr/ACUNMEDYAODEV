﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PR19OOP.Interfaces
{
    interface IYetenekler
    {
        void askereGit(string isim);

        void ehliyetAl(string isim);
       
    }
}

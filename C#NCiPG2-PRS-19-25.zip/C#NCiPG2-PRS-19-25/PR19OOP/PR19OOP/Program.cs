﻿// See https://aka.ms/new-console-template for more information

using PR19OOP.Abstracts;
using PR19OOP.Classes;
using PR19OOP.Constructors;
using PR19OOP.Generics;
using System.Collections;
using System.Collections.Generic;

Console.WriteLine("Hello, World!");


//bir class tan nesne oluşturma
//ClassIsmi nesneAdi = new ClassIsmi();

Insan i = new Insan();
i.adi = "ibrahim";
i.soyadi = "gökyar";
i.yas = 46;
i.maas = 3.14;
i.cinsiyet = false;

Insan i2 = new Insan();
i2.adi = "hakan";
i2.soyadi = "yılmaz";
i2.yas = 55;
i2.maas = 5.5;
i2.cinsiyet = true;

Insan i3 = new Insan();
i3.adi = "hakan";
i3.soyadi = "yılmaz";
i3.yas = 55;
i3.maas = 5.5;
i3.cinsiyet = true;

Insan i4 = new Insan();
i4.adi = "hakan";
i4.soyadi = "yılmaz";
i4.yas = 55;
i4.maas = 5.5;
i4.cinsiyet = true;



new Insan("hakan", "yılmaz", 33, 3.14, true);
new Insan("hakan", "yılmaz", 33, 3.14, true);
new Insan("hakan", "yılmaz", 33, 3.14, true);
new Insan("hakan", "yılmaz", 33, 3.14, true);



//Insan class ı içindeki uyu metodunu çağırdık
i.uyu("hakan","yılmaz");
i.uyu(i.adi,i.soyadi);
int gelenYas = i.yasHesapla(1980);
Console.WriteLine("Yaşınız : " + gelenYas);

//Insan classından i2 adında nesne oluşturulurken kendisine göndermiş olduğum değerler
//ilgili değişkenlere atanır. 
//Insan i2 = new Insan("hakan", "yılmaz");

//ınsan class ından nesne oluşturulurken class ın içindeki tüm değişenlere baştan göndermiş olduğum
//değerler atanır
//Insan i3 = new Insan("metin", "yıldız", 44, 4.44, true);


Araba a = new Araba();
a.marka = "Bmw";
a.model = "x5";
a.kapiSayisi = 4;
a.pencereSayisi = 4;
a.git("Mercedes","XL");
a.git(a.marka,a.model);


Matematik m = new Matematik();
//1. yöntem 
int gelenDeger = m.topla(5, 5);
Console.WriteLine("Toplam : " + gelenDeger);

Console.WriteLine("3 Sayının toplamı :" +m.topla(5, 5, 5));
//2. yöntem
Console.WriteLine("Toplam 2. yöntem : " + m.topla(10, 10));

Console.WriteLine("Çıkan Sonuç : " + m.cikar(10, 10));

Console.WriteLine("Çarpım Sonucu : " + m.carp(10, 10));

Console.WriteLine("Bölüm Sonucu : " + m.bol(10, 10));


Anne an = new Anne();
an.adi = "fahriye";
an.soyadi = "gökyar";
an.uyu(an.adi, an.soyadi);
an.ekranaYaz(an.adi, an.soyadi);
an.oku(an.adi);
an.dinle(an.adi);
an.yaz(an.adi);

Baba b = new Baba();
b.ekranaYaz("Kasım", "Gökyar");
b.oku("Kasım");

Cocuk c = new Cocuk();
c.ekranaYaz("ibrahim", "gökyar");

Bmw bm = new Bmw();
bm.markaModelYaz("Bmw", "X5");

Mercedes me = new Mercedes();
me.markaModelYaz("Mercedes", "XL");

Porche p = new Porche();
p.markaModelYaz("Porche", "Carrera");

AkilliCocuk ak = new AkilliCocuk();
ak.adi = "Hakan";
ak.soyadi = "Yılmaz";
ak.sifat = "Akıllıdır";
ak.adSoyadSifatYaz(ak.adi, ak.soyadi, ak.sifat);
ak.askereGit(ak.adi);
ak.ehliyetAl(ak.adi);
ak.klubeGit(ak.adi);

UsluCocuk us = new UsluCocuk();
us.adSoyadSifatYaz("Mehmet", "Yıldız", "Usludur");
us.askereGit("Mehmet");
us.ehliyetAl("Mehmet");


HiperAktifCocuk hp = new HiperAktifCocuk();
hp.adi = "Hüseyin";
hp.ehliyetAl(hp.adi);


//abstract class ların nesnesi oluşturulamaz
//Calisan ca = new Calisan();

GenelMudur gm = new GenelMudur();
Mudur mu = new Mudur();
Programci pr = new Programci();
Stajyer s = new Stajyer();


double toplamMaas = 0.0;

//toplamMaas = toplamMaas+ gm.maasiniziNedir();
toplamMaas += gm.maasiniziNedir();
toplamMaas += mu.maasiniziNedir();
toplamMaas += pr.maasiniziNedir();
toplamMaas += s.maasiniziNedir();

Console.WriteLine("Toplam : " + toplamMaas + " TL maaş alıyorlar");






//aynı türden değişkenleri yada objeleri bir isim altında tutmamızı sağlar
//1. yöntem
//hangitype[] diziAdi = new hangitype[7];
//dizilerin ilk değişkeni elemanı indis index numarası 0 dan başlar
string[] gunler = new string[7];
string[] gunler2 = { "pazartesi", "salı", "çarşamba", "perşembe", "cuma", "cumartesi", "pazar" };
gunler[0] = "pazartesi";
gunler[1] = "salı";
gunler[2] = "çarşamba";
gunler[3] = "perşembe";
gunler[4] = "cuma";
gunler[5] = "cumartesi";
gunler[6] = "pazar";
//arrayboundexofception dizinin ilgili değişkeni yoksa ve biz değişkene erişmeye yada bir değer atamaya çalışırsak bir hata alırız.
//gunler[7] = "pzr1";

//if(koşul) {   } else if (koşul ) {  } else {  }

int yas = 27;
//or veya  operatör  --yas++ bitwise operator 
if(yas> 0  && yas<=18)
{
    Console.WriteLine("küçüksünüz");
}
else if(yas>18 && yas< 35)
{
    Console.WriteLine("gençsiniz");
}
else
{
    Console.WriteLine("sisteme giriş yapamazsınız!!");
}



//Console.WriteLine("Doğum yılınızı giriniz: ");
//int dogumYili = Convert.ToInt32(Console.ReadLine());
//Console.WriteLine("Yaşınız :" +i.yasHesapla(dogumYili));



//for döngüsü

//Console.WriteLine("Merhaba Dünya");
//Console.WriteLine("Merhaba Dünya");
//Console.WriteLine("Merhaba Dünya");
//Console.WriteLine("Merhaba Dünya");
//Console.WriteLine("Merhaba Dünya");
//Console.WriteLine("Merhaba Dünya");
//Console.WriteLine("Merhaba Dünya");
//Console.WriteLine("Merhaba Dünya");
//Console.WriteLine("Merhaba Dünya");
//Console.WriteLine("Merhaba Dünya");

//for(sayac; sayac< tekrar edilecek; sayac++)   {   }

for(int sayac=0; sayac <10;sayac++)
{
    //yapılması gereken işlem yapılacak
    Console.WriteLine("Merhaba Dünya");
}



for(int sayac2=0; sayac2<gunler.Length; sayac2++)
{
    Console.WriteLine(gunler[sayac2]);
}

//diziler 2. yöntem
//hangitype[] diziAdi = {  };
//n elemanlı sayısı belli olmayan bir  dizi tanımladık
int[] sayilar = { 3, 5, 7, 11, 22, 33, 44, 55, 66, 77, 88, 99, 102,121,35 };
int sayiToplam = 0;
for(int x=0; x<sayilar.Length;x++)
{
    Console.WriteLine("Sayı  : " + sayilar[x]);
    // sayiToplam = sayiToplam + sayilar[x];
    sayiToplam += sayilar[x];
}
Console.WriteLine("Sayıların Toplamı : " + sayiToplam);


for(int zz=0;zz<100000; zz++)
{
    new Insan("hüseyin", "yılmaz", 33, 3.14, true);
}




Goz goz = new Goz("kahverengi");
Kulak kulak = new Kulak("Kepçe");
Burun burun = new Burun("Kemer");
Kafa kafa = new Kafa(goz,kulak,burun);
YeniInsan yeni = new YeniInsan(kafa,"ibrahim","gökyar");
yeni.randevuKaydet();


ArrayList liste = new ArrayList();
liste.Add("ibrahim");
liste.Add(35);
liste.Add(3.14);
liste.Add(true);
liste.Add(us);
liste.Add("hakan");
liste.RemoveAt(2);
liste.Insert(2, "hüseyin");
if (liste.Contains("ibrahim2"))
{
    Console.WriteLine("bu eleman liste içinde var");
}
else
{
    Console.WriteLine("bu eleman liste içinde yok");
}
Console.WriteLine("listede : " + liste.Count + " eleman var");
//liste.Clear();

for (int j = 0; j < liste.Count; j++)
{
    // Kutudan çıkarma, gerçek int değerine erişmek için gerçekleşir
   // string str = (string)liste[j];
    // Kutudan çıkarma, gerçek int değerine erişmek için gerçekleşir
   // int geriAlinanYas = (int)liste[j];
}

//değer tipidir -stack tutulur 
int n = 123;

//boxing değer tipli bir değişkeni referans tipli bir değişkene dönüştürüyoruz

object obj = n;

//unboxing -- referanslı tipli bir değişkeni değer tipli bir değişkene dönüştürme
//convert etme casting 
n = (int)obj;

//casting convert etme
int abc = Convert.ToInt32("35");

//generic liste dir generic listeler baştan farklı bir tipte verinin listeye eklenmesini engeller
//boxing unboxing işlemleri gibi performans azaltıcı işlemlere de sebep olmaz.
List<string> liste2 = new List<string>();
liste2.Add("ibrahim");
liste2.Add("hakan");
liste2.Add("mert");
liste2.Add("metin");
liste2.Add("aslı");
liste2.Add("melek");

//içine Calisan tipinde veri alan bir liste 
List<Calisan> calisanListesi = new List<Calisan>();
calisanListesi.Add(gm);
calisanListesi.Add(mu);
calisanListesi.Add(pr);
calisanListesi.Add(s);


double calisanToplam = 0;
//foreach   for(int j=0; j<calisanListesi.Count; j++) {    }
foreach(Calisan calisan in calisanListesi)
{
    calisanToplam += calisan.maasiniziNedir();
}

Console.WriteLine("Çalışanların toplam yeni maaşı : " + calisanToplam+ " TL dir...");


Animal animal = new Animal();
animal.nickName = "Boncuk";
//animal.save(animal);

Person person = new Person();
person.name = "ibrahim";
//person.save(person);


Urun urun = new Urun();
urun.urunAdi = "Bilgisayar";

List<int> intSayilar = new List<int> { 3, 5, 8, 9, 11 };
List<double> doubleSayilar = new List<double> { 3.5, 5.3, 8.2, 9.1, 11.5 };
List<string> isimler = new List<string> { "ibrahim","hakan","mehmet","mert","aslı" };

GenericMethodOrnek gmo =  new GenericMethodOrnek();
//gmo.save(urun);  parametre alan constructor kullanıyor gibi
//gmo.save(new Person { name = "Ali" });
//gmo.save(new Animal { nickName = "Boncuk" });
//gmo.save(new Urun { urunAdi = "Klavye",marka="Asus" });
//gmo.Yazdir(isimler);


//Generic Classlar için örnekler
//factory ve singleton design patternleri kullanarak buradaki nesne oluşturma işini
//daha iyi yönetebiliriz. 
//Generic yapılar, belirli bir veri tipiyle çalışacak şekilde tasarlandığında, derleme zamanı hatalarını önleyerek tip güvenliği sağlar. Böylece, yanlış veri tipleriyle çalışmayı engeller.
//Farklı veri tipleri için aynı işlemi yapan farklı sınıflar yazmak yerine, tek bir Generic Class kullanarak kod tekrarını önleyebilirsiniz.
//Eğer Generic kullanmazsanız, her veri tipi için ayrı sınıflar oluşturmanız gerekir:
GenericClassOrnek<Person> genericClassPerson = new GenericClassOrnek<Person>();
genericClassPerson.Save(person);


GenericClassOrnek<Animal> genericClassAnimal = new GenericClassOrnek<Animal>();
genericClassAnimal.Save(animal);


//ArrayListIbrahim arrayListIbrahim = new ArrayListIbrahim();
//arrayListIbrahim.listele();
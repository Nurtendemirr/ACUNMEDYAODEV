﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblAdi = new Label();
            lblSoyadi = new Label();
            lblGozRengi = new Label();
            lblKulak = new Label();
            lblBurun = new Label();
            txtAdi = new TextBox();
            txtSoyadi = new TextBox();
            cmbGozRengi = new ComboBox();
            cmbKulak = new ComboBox();
            cmbBurun = new ComboBox();
            btnKaydet = new Button();
            lblSonuc = new Label();
            SuspendLayout();
            // 
            // lblAdi
            // 
            lblAdi.AutoSize = true;
            lblAdi.Location = new Point(187, 55);
            lblAdi.Name = "lblAdi";
            lblAdi.Size = new Size(34, 15);
            lblAdi.TabIndex = 0;
            lblAdi.Text = "Adı : ";
            // 
            // lblSoyadi
            // 
            lblSoyadi.AutoSize = true;
            lblSoyadi.Location = new Point(187, 120);
            lblSoyadi.Name = "lblSoyadi";
            lblSoyadi.Size = new Size(48, 15);
            lblSoyadi.TabIndex = 1;
            lblSoyadi.Text = "Soyadı :";
            // 
            // lblGozRengi
            // 
            lblGozRengi.AutoSize = true;
            lblGozRengi.Location = new Point(187, 187);
            lblGozRengi.Name = "lblGozRengi";
            lblGozRengi.Size = new Size(66, 15);
            lblGozRengi.TabIndex = 2;
            lblGozRengi.Text = "Göz Rengi :";
            // 
            // lblKulak
            // 
            lblKulak.AutoSize = true;
            lblKulak.Location = new Point(187, 248);
            lblKulak.Name = "lblKulak";
            lblKulak.Size = new Size(45, 15);
            lblKulak.TabIndex = 3;
            lblKulak.Text = "Kulak : ";
            // 
            // lblBurun
            // 
            lblBurun.AutoSize = true;
            lblBurun.Location = new Point(187, 309);
            lblBurun.Name = "lblBurun";
            lblBurun.Size = new Size(45, 15);
            lblBurun.TabIndex = 4;
            lblBurun.Text = "Burun :";
            // 
            // txtAdi
            // 
            txtAdi.Location = new Point(385, 53);
            txtAdi.Name = "txtAdi";
            txtAdi.Size = new Size(199, 23);
            txtAdi.TabIndex = 5;
            // 
            // txtSoyadi
            // 
            txtSoyadi.Location = new Point(386, 120);
            txtSoyadi.Name = "txtSoyadi";
            txtSoyadi.Size = new Size(198, 23);
            txtSoyadi.TabIndex = 6;
            // 
            // cmbGozRengi
            // 
            cmbGozRengi.FormattingEnabled = true;
            cmbGozRengi.Items.AddRange(new object[] { "Seçiniz", "Kahverengi", "Yeşil", "Mavi", "Ela", "Siyah" });
            cmbGozRengi.Location = new Point(385, 184);
            cmbGozRengi.Name = "cmbGozRengi";
            cmbGozRengi.Size = new Size(199, 23);
            cmbGozRengi.TabIndex = 7;
            cmbGozRengi.SelectedIndexChanged += cmbGozRengi_SelectedIndexChanged;
            // 
            // cmbKulak
            // 
            cmbKulak.FormattingEnabled = true;
            cmbKulak.Items.AddRange(new object[] { "Seçiniz", "Kepçe", "Geniş", "Dar" });
            cmbKulak.Location = new Point(386, 248);
            cmbKulak.Name = "cmbKulak";
            cmbKulak.Size = new Size(192, 23);
            cmbKulak.TabIndex = 8;
            cmbKulak.SelectedIndexChanged += cmbGozKulak_SelectedIndexChanged;
            // 
            // cmbBurun
            // 
            cmbBurun.FormattingEnabled = true;
            cmbBurun.Items.AddRange(new object[] { "Seçiniz", "Kemer", "Geniş", "Yassı", "Dar" });
            cmbBurun.Location = new Point(388, 309);
            cmbBurun.Name = "cmbBurun";
            cmbBurun.Size = new Size(190, 23);
            cmbBurun.TabIndex = 9;
            cmbBurun.SelectedIndexChanged += cmbBurun_SelectedIndexChanged;
            // 
            // btnKaydet
            // 
            btnKaydet.Location = new Point(437, 379);
            btnKaydet.Name = "btnKaydet";
            btnKaydet.Size = new Size(141, 58);
            btnKaydet.TabIndex = 10;
            btnKaydet.Text = "KAYDET";
            btnKaydet.UseVisualStyleBackColor = true;
            btnKaydet.Click += btnKaydet_Click;
            // 
            // lblSonuc
            // 
            lblSonuc.AutoSize = true;
            lblSonuc.Location = new Point(170, 487);
            lblSonuc.Name = "lblSonuc";
            lblSonuc.Size = new Size(49, 15);
            lblSonuc.TabIndex = 11;
            lblSonuc.Text = "Sonuç : ";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 525);
            Controls.Add(lblSonuc);
            Controls.Add(btnKaydet);
            Controls.Add(cmbBurun);
            Controls.Add(cmbKulak);
            Controls.Add(cmbGozRengi);
            Controls.Add(txtSoyadi);
            Controls.Add(txtAdi);
            Controls.Add(lblBurun);
            Controls.Add(lblKulak);
            Controls.Add(lblGozRengi);
            Controls.Add(lblSoyadi);
            Controls.Add(lblAdi);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblAdi;
        private Label lblSoyadi;
        private Label lblGozRengi;
        private Label lblKulak;
        private Label lblBurun;
        private TextBox txtAdi;
        private TextBox txtSoyadi;
        private ComboBox cmbGozRengi;
        private ComboBox cmbKulak;
        private ComboBox cmbBurun;
        private Button btnKaydet;
        private Label lblSonuc;
    }
}

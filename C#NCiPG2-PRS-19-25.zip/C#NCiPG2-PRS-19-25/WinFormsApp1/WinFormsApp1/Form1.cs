namespace WinFormsApp1
{
    public partial class Form1 : Form
    {

        //global de�i�ken
        string adi;
        string soyadi;
        string gozRengi;
        string kulakSekil;
        string burunSekil;
        public Form1()
        {
            InitializeComponent();
        }




        private void btnKaydet_Click(object sender, EventArgs e)
        {

            //txtadi componenit i�ine girilen de�eri bize Text ile string verir
            //local variable
            adi = txtAdi.Text;
            soyadi = txtSoyadi.Text;
            lblSonuc.Text = "Randevu Alan Ki�inin Ad�  : " + adi + " Soyad� : " +soyadi + " G�z Rengi : " +gozRengi+ " Kula�� : " +kulakSekil+ " Burnu : " + burunSekil;
        }

        private void cmbGozRengi_SelectedIndexChanged(object sender, EventArgs e)
        {
            //ilgili comboboxtan se�mi� oldu�umuz eleman� bize verir
            gozRengi = cmbGozRengi.SelectedItem.ToString();
        }

        private void cmbGozKulak_SelectedIndexChanged(object sender, EventArgs e)
        {
            //ilgili comboboxtan se�mi� oldu�umuz eleman� bize verir
            kulakSekil = cmbKulak.SelectedItem.ToString();
        }

        private void cmbBurun_SelectedIndexChanged(object sender, EventArgs e)
        {
            burunSekil = cmbBurun.SelectedItem.ToString();
        }
    }
}
